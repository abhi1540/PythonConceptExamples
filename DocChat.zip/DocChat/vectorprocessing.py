from langchain.vectorstores import Chroma
from embedding import EmbeddingProcess
import chromadb
from settings import CHROMA_SETTINGS
from ingestion import PreprocessingAndIngest


class CreateVectorStore:

    def __init__(self, vectorstorepath,
               embeddings: EmbeddingProcess,
              processandingestion: PreprocessingAndIngest) -> None:

        self.vectorstorepath = vectorstorepath
        self.embeddings = embeddings
        self.processandingestion = processandingestion



    def vectoringestion(self) -> None:

        if self.does_vectorstore_exist():
            print("if exists")
            # Update and store locally vectorstore
            print(f"Appending to existing vectorstore at {self.vectorstorepath}")
            db = Chroma(persist_directory=self.vectorstorepath, embedding_function=self.embeddings, client_settings=CHROMA_SETTINGS)
            collection = db.get()
            texts = self.processandingestion.process_documents([metadata['source'] for metadata in collection['metadatas']])
            print(f"Creating embeddings. May take some minutes...")
            db.add_documents(texts)
        else:
            # Create and store locally vectorstore
            print("Creating new vectorstore")
            texts = self.processandingestion.process_documents()
            print(f"Creating embeddings. May take some minutes...")
            db = Chroma.from_documents(texts, self.embeddings, persist_directory=self.vectorstorepath, client_settings=CHROMA_SETTINGS)
        db.persist()
        db = None

    def does_vectorstore_exist(self) -> bool:
        """
        Checks if vectorstore exists
        """

        db = Chroma(persist_directory=self.vectorstorepath, embedding_function=self.embeddings, client_settings=CHROMA_SETTINGS)
        print(db.get())
        if not db.get()['documents']:
            return False
        return True