import os
from embedding import EmbeddingProcess
from vectorprocessing import PreprocessingAndIngest
from vectorprocessing import CreateVectorStore
from dotenv import load_dotenv
from loadvectorstore import LoadVectorstore

from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    GenerationConfig,
    LlamaForCausalLM,
    LlamaTokenizer,
    pipeline,
)
import torch
from langchain.llms import GPT4All, LlamaCpp
from langchain.llms import HuggingFacePipeline
from langchain.memory import ConversationBufferMemory
from langchain.prompts import PromptTemplate
from langchain.chains import RetrievalQA
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler

load_dotenv()


def main():

    PERSIST_DIRECTORY = os.environ.get('PERSIST_DIRECTORY')
    EMBEDDINGS_MODEL_PATH = os.environ.get('EMBEDDINGS_MODEL_NAME')
    EMBEDDINGS_FUNCTION_NAME = os.environ.get('EMBEDDINGS_FUNCTION_NAME')
    DEVICE_TYPE = os.environ.get('DEVICE_TYPE')
    SOURCE_DIR = os.environ.get('SOURCE_DIR')
    MODEL_PATH = os.environ.get('MODEL_PATH')
    MODEL_N_CTX = os.environ.get('MODEL_N_CTX')
    MODEL_N_BATCH = os.environ.get('MODEL_N_BATCH')

    print("embedding.........")
    embeddings = EmbeddingProcess(EMBEDDINGS_FUNCTION_NAME, EMBEDDINGS_MODEL_PATH, DEVICE_TYPE).embeddings()
    print("embedding done...........")
    ingestionprocess = PreprocessingAndIngest(SOURCE_DIR)
    print("create vector store......")
    #createvectorstore = CreateVectorStore(PERSIST_DIRECTORY, embeddings, ingestionprocess)
    #createvectorstore.vectoringestion()
    db = LoadVectorstore(PERSIST_DIRECTORY, embeddings).loadvectorstore()
    callbacks =  [StreamingStdOutCallbackHandler()]

    llm = LlamaCpp(model_path=MODEL_PATH, max_tokens=MODEL_N_CTX, n_batch=MODEL_N_BATCH, callbacks=callbacks, n_gpu_layers=26, verbose=False)
    #llm = GPT4All(model=MODEL_PATH, backend='gptj', n_batch=MODEL_N_BATCH, callbacks=callbacks, verbose=False)
    retriever = db.as_retriever()
    

    template = """Use the following pieces of context to answer the question at the end. If you don't know the answer,\
    just say that you don't know, don't try to make up an answer.

    {context}

    {history}
    Question: {question}
    Helpful Answer:"""

    prompt = PromptTemplate(input_variables=["history", "context", "question"], template=template)
    memory = ConversationBufferMemory(input_key="question", memory_key="history")



    qa = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=retriever,
        return_source_documents=True,
        chain_type_kwargs={"prompt": prompt, "memory": memory},
    )
    # Interactive questions and answers
    while True:
        query = input("\nEnter a query: ")
        if query == "exit":
            break
        # Get the answer from the chain
        res = qa(query)
        answer, docs = res["result"], res["source_documents"]

        # Print the result
        print("\n\n> Question:")
        print(query)
        print("\n> Answer:")
        print(answer)

        if show_sources:  # this is a flag that you can set to disable showing answers.
            # # Print the relevant sources used for the answer
            print("----------------------------------SOURCE DOCUMENTS---------------------------")
            for document in docs:
                print("\n> " + document.metadata["source"] + ":")
                print(document.page_content)
            print("----------------------------------SOURCE DOCUMENTS---------------------------")

if __name__ == "__main__":
    main()