from langchain.embeddings import HuggingFaceEmbeddings

class EmbeddingProcess:

    def __init__(self, embeddingmodelname: HuggingFaceEmbeddings,
                 embeddingmodelpath: str,
                 device_type: str):

        self.embedding_model_name = embeddingmodelname
        self.embedding_model_path = embeddingmodelpath
        self.device_type = device_type


    def embeddings(self):
        embeddings = HuggingFaceEmbeddings(model_name=self.embedding_model_path, model_kwargs={"device": self.device_type})

        return embeddings