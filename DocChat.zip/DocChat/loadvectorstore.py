from embedding import EmbeddingProcess
from langchain.vectorstores import Chroma
from settings import CHROMA_SETTINGS

class LoadVectorstore:

    def __init__(self, 
                 vectorstorepath: str,
                 embeddings: EmbeddingProcess,
                 ):
        self.vectorstorepath = vectorstorepath
        self.embeddings = embeddings


    def loadvectorstore(self):

        db = Chroma(persist_directory=self.vectorstorepath, embedding_function=self.embeddings,
                   client_settings=CHROMA_SETTINGS)
        return db


