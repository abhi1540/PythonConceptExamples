from dotenv import load_dotenv
import os

from settings import CHROMA_SETTINGS, MAPPING_DOC, THREAD_COUNT, CHUNK_SIZE, CHUNK_OVERLAP
import chromadb
import glob
from typing import List
from dotenv import load_dotenv
from multiprocessing import Pool
from tqdm import tqdm
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import Chroma
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.docstore.document import Document

#�Load environment variables
#persist_directory = os.environ.get('PERSIST_DIRECTORY')
#source_directory = os.environ.get('SOURCE_DIRECTORY', 'source_documents')
#embeddings_model_name = os.environ.get('EMBEDDINGS_MODEL_NAME')
#chunk_size = 500
#chunk_overlap = 50

class PreprocessingAndIngest:

    def __init__(self, source_dir: str
                 ) -> None:
        self.source_dir = source_dir

    def load_single_document(self, file_path: str) -> List[Document]:
        ext = "." + file_path.rsplit(".", 1)[-1].lower()
        if ext in MAPPING_DOC:
            loader_class, loader_args = MAPPING_DOC[ext]
            loader = loader_class(file_path, **loader_args)
            return loader.load()

        raise ValueError(f"Unsupported file extension '{ext}'")


    def load_documents(self) -> List[Document]:
        """
        Loads all documents from the source documents directory, ignoring specified files
        """
        all_files = []
        for ext in MAPPING_DOC:
            all_files.extend(
                glob.glob(os.path.join( self.source_dir, f"**/*{ext.lower()}"), recursive=True)
            )
        filtered_files = [file_path for file_path in all_files]

        with Pool(processes=THREAD_COUNT) as pool:
            results = []
            with tqdm(total=len(filtered_files), desc='Loading new documents') as pbar:
                for i, docs in enumerate(pool.imap_unordered(self.load_single_document, filtered_files)):
                    results.extend(docs)
                    pbar.update()

        return results


    def process_documents(self) -> List[Document]:
        """
        Load documents and split in chunks
        """
        print(f"Loading documents from {self.source_dir}")
        documents = self.load_documents()
        if not documents:
            print("No new documents to load")
            #exit(0)
        print(f"Loaded {len(documents)} new documents from {self.source_dir}")
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=CHUNK_SIZE, chunk_overlap=CHUNK_OVERLAP)
        texts = text_splitter.split_documents(documents)
        print(f"Split into {len(texts)} chunks of text (max. {CHUNK_SIZE} tokens each)")
        return texts


        


