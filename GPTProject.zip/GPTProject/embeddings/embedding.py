import logging
import os
from injector import inject, singleton
from llama_index import MockEmbedding
from llama_index.embeddings.base import BaseEmbedding
from dotenv import load_dotenv
from private_gpt.paths import models_cache_path
from private_gpt.settings.settings import Settings

logger = logging.getLogger(__name__)
load_dotenv()


#�Load environment variables
models_cache_path = os.environ.get('MODEL_CACHE_PATH')
source_directory = os.environ.get('SOURCE_DIRECTORY', 'source_documents')
embeddings_model_name = os.environ.get('EMBEDDINGS_MODEL_NAME')

@singleton
class EmbeddingComponent:
    embedding_model: BaseEmbedding

    @inject
    def __init__(self, embedding_model_name, cache_path) -> None:
        self.embedding_model_name = embedding_model_name
        self.cache_path = models_cache_path
        logger.info("Initializing the embedding model in local mode")
        from llama_index.embeddings import HuggingFaceEmbedding

        self.embedding_model = HuggingFaceEmbedding(
            model_name=self.embedding_model_name,
            cache_folder= self.cache_path,
                )

