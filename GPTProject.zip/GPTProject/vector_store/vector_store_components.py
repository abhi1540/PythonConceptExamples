import logging
import typing

from injector import inject, singleton
from llama_index import VectorStoreIndex
from llama_index.indices.vector_store import VectorIndexRetriever
from llama_index.vector_stores.types import VectorStore



logger = logging.getLogger(__name__)

@singleton
class VectorStoreComponent:
    vector_store: VectorStore

    @inject
    def __init__(self, persist_db_location) -> None:

        from llama_index.vector_stores.qdrant import QdrantVectorStore
        from qdrant_client import QdrantClient


        client = QdrantClient(
               path=persist_db_location
        )
        self.vector_store = typing.cast(
            VectorStore,
            QdrantVectorStore(
                client=client,
                collection_name="private_documents",
            ), 
        )


    @staticmethod
    def get_retriever(
        index: VectorStoreIndex,
        similarity_top_k: int = 2,
    ) -> VectorIndexRetriever:
        # This way we support qdrant (using doc_ids) and chroma (using where clause)
        return VectorIndexRetriever(
            index=index,
            similarity_top_k=similarity_top_k,
            doc_ids=None,
        )

    def close(self) -> None:
        if hasattr(self.vector_store.client, "close"):
            self.vector_store.client.close()

