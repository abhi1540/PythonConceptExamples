import logging

from injector import inject, singleton
from llama_index.embeddings.base import BaseEmbedding


logger = logging.getLogger(__name__)


@singleton
class EmbeddingComponent:
    embedding_model: BaseEmbedding

    @inject
    def __init__(self, model_path) -> None:
        logger.info("Initializing the embedding model...................")
        from llama_index.embeddings import HuggingFaceEmbedding

        self.embedding_model = HuggingFaceEmbedding(
            model_name=model_path,
        )
