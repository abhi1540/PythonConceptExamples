
import logging

from injector import inject, singleton
from llama_index.llms.base import LLM
from local_llm.prompt import get_prompt_style


logger = logging.getLogger(__name__)


@singleton
class LLMComponent:
    llm: LLM

    @inject
    def __init__(self, local_llm_path, prompt_style, max_new_token) -> None:
        logger.info("Initializing the LLM in Local mode")
        from llama_index.llms import LlamaCPP

        prompt_style = get_prompt_style(prompt_style)

        self.llm = LlamaCPP(
            model_path=local_llm_path,
            temperature=0.1,
            max_new_tokens=max_new_token,
            # llama2 has a context window of 4096 tokens,
            # but we set it lower to allow for some wiggle room
            context_window=3900,
            generate_kwargs={},
            # All to GPU
            model_kwargs={"n_gpu_layers": -1},
            # transform inputs into Llama2 format
            messages_to_prompt=prompt_style.messages_to_prompt,
            completion_to_prompt=prompt_style.completion_to_prompt,
            verbose=True,
        )

