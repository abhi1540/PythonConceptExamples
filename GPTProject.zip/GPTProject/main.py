# -*- coding: Windows-1252 -*-
import os
from dotenv import load_dotenv
from ingestionservice import IngestService
from embedding.embedding_component import EmbeddingComponent
from local_llm.llm_component import LLMComponent
from node_store.node_store_component import NodeStoreComponent
from vector_store.vector_store_components import VectorStoreComponent


load_dotenv()


#�Load environment variables
local_llm_path = os.environ.get('LLM_MODEL_PATH')
prompt_style= os.environ.get('PROMPT_STYLE')
max_new_token = os.environ.get('MAX_NEW_TOKEN')
persist_db_location = os.environ.get('PERSIST_DB_DIRECTORY')
source_directory = os.environ.get('SOURCE_DIR')
embeddings_model_name = os.environ.get('EMBEDDINGS_MODEL_NAME')
count_workers = os.environ.get('COUNT_WORKER')

if __name__ =='__main__':
    llm_component = LLMComponent(local_llm_path, prompt_style, max_new_token)
    vector_store_component = VectorStoreComponent(persist_db_location)
    embedding_component = EmbeddingComponent(embeddings_model_name)
    node_store_component = NodeStoreComponent(persist_db_location)
    ingest_serv = IngestService(llm_component,
                                vector_store_component,
                                embedding_component,
                                node_store_component,
                                count_workers,
                                source_directory)

    ingest_serv.bulk_ingest()
