# -*- coding: Windows-1252 -*-
import os
import logging
from dotenv import load_dotenv
from ingestionservice import IngestService
from embedding.embedding_component import EmbeddingComponent
from local_llm.llm_component import LLMComponent
from node_store.node_store_component import NodeStoreComponent
from vector_store.vector_store_components import VectorStoreComponent
from pathlib import Path
from chat_service import ChatService

load_dotenv()
logger = logging.getLogger(__name__)


#�Load environment variables
local_llm_path = os.environ.get('LLM_MODEL_PATH')
prompt_style= os.environ.get('PROMPT_STYLE')
max_new_token = int(os.environ.get('MAX_NEW_TOKEN'))
persist_db_location = os.environ.get('PERSIST_DB_DIRECTORY')
source_directory = os.environ.get('SOURCE_DIR')
embeddings_model_name = os.environ.get('EMBEDDINGS_MODEL_NAME')
count_workers = int(os.environ.get('COUNT_WORKER'))

if __name__ =='__main__':
    llm_component = LLMComponent(local_llm_path, prompt_style, max_new_token)
    vector_store_component = VectorStoreComponent(persist_db_location)
    embedding_component = EmbeddingComponent(embeddings_model_name)
    node_store_component = NodeStoreComponent(persist_db_location)
    ingest_serv = IngestService(llm_component,
                                vector_store_component,
                                embedding_component,
                                node_store_component,
                                count_workers
                                )
    
    #total_documents = 0
    current_document_count = 0
    _files_under_root_folder: list[Path] = list()

    def ingest_folder(folder_path: Path) -> None:
        # Count total documents before ingestion
        _find_all_files_in_folder(folder_path)
        _ingest_all(_files_under_root_folder)



    def _find_all_files_in_folder(root_path: Path) -> None:
        """Search all files under the root folder recursively.
        Count them at the same time
        """
        for file_path in root_path.iterdir():
            if file_path.is_file():
                #total_documents += 1
                _files_under_root_folder.append(file_path)
            elif file_path.is_dir():
                _find_all_files_in_folder(file_path)

    def _ingest_all(files_to_ingest: list[Path]) -> None:
        logger.info("Ingesting files=%s", [f.name for f in files_to_ingest])
        ingest_serv.bulk_ingest([(str(p.name), p) for p in files_to_ingest])
    
    #ingest_folder(Path(source_directory))
    chatservice = ChatService(llm_component,
                                vector_store_component,
                                embedding_component,
                                node_store_component,)

    from llama_index.retrievers import BM25Retriever

    # retireve the top 10 most similar nodes using embeddings
    vector_retriever = chatservice.index.as_retriever(similarity_top_k=10)

    # retireve the top 10 most similar nodes using bm25
    bm25_retriever = BM25Retriever.from_defaults(docstore=node_store_component.doc_store, similarity_top_k=10)

    from llama_index.retrievers import BaseRetriever


    class HybridRetriever(BaseRetriever):
        def __init__(self, vector_retriever, bm25_retriever):
            self.vector_retriever = vector_retriever
            self.bm25_retriever = bm25_retriever
            super().__init__()

        def _retrieve(self, query, **kwargs):
            bm25_nodes = self.bm25_retriever.retrieve(query, **kwargs)
            vector_nodes = self.vector_retriever.retrieve(query, **kwargs)

            # combine the two lists of nodes
            all_nodes = []
            node_ids = set()
            for n in bm25_nodes + vector_nodes:
                if n.node.node_id not in node_ids:
                    all_nodes.append(n)
                    node_ids.add(n.node.node_id)
            return all_nodes

    hybrid_retriever = HybridRetriever(vector_retriever, bm25_retriever)
    from llama_index.postprocessor import SentenceTransformerRerank

    reranker = SentenceTransformerRerank(top_n=4, model="BAAI/bge-reranker-base")


    from llama_index.query_engine import RetrieverQueryEngine

    query_engine = RetrieverQueryEngine.from_args(
        retriever=hybrid_retriever,
        node_postprocessors=[reranker],
        service_context=chatservice.service_context
    )

    response = query_engine.query(
        "when did mumbai attack happend?"
    )

    from llama_index.response.notebook_utils import display_response

    display_response(response)